
library(testthat)
library(ProtExp)

test_check("ProtExp")
